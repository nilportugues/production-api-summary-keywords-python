# coding=utf-8
import application

app = application.app
app.run(port=8080)